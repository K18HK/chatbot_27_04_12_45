# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 03:11:40 2020

@author: Nemesis
"""


import json

data=json.loads(open('nfL6.json','r').read())

train=[]

for k,row in enumerate(data):
    train.append(row['question'])
    train.append(row['answer'])
    

from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

chatbot = ChatBot('Abhishek')

trainer=ListTrainer(chatbot)

trainer.train(train)

while True:
	request=input('You: ')
	response = chatbot.get_response(request)
	print('Bot: ',response)
